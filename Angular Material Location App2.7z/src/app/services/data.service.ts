import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Location } from '../models/location';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatDialogRef } from '@angular/material/dialog';
import { AddDialogComponent } from '../dialogs/add/add.dialog.component';

@Injectable()
export class DataService {
  readonly API_URL = 'http://localhost:3000/posts/';

  dataChange: BehaviorSubject<Location[]> = new BehaviorSubject<Location[]>([]);
  dialogData: any;
  facilityTime: any;
  public indexLocation: number = 0;

  constructor(private httpClient: HttpClient) { }

  get data(): Location[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  getAllLocations(): void {
    this.httpClient.get<Location[]>(this.API_URL).subscribe(data => {
      this.dataChange.next(data);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }

  addLocation(location: Location, dialogRef: MatDialogRef<AddDialogComponent>): void {
    location.id = this.getIndexLocation();
    this.dialogData = location;
    this.httpClient.post<Location>(this.API_URL, location).subscribe(data => {
      dialogRef.close(1);

    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }

  updateLocation(location: Location, dialogRef: MatDialogRef<AddDialogComponent>): void {
    this.dialogData = location;
    this.httpClient.put<Location>(this.API_URL + location.id, location).subscribe(data => {
      //this.dialogData = location;
      dialogRef.close(1);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }

  deleteLocation(id: number): void {
    this.httpClient.delete<Location>(this.API_URL + id).subscribe(data => {
      console.log(data);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }

  addFacilityTime(data) {
    this.facilityTime = data;
  }

  getFacilityTime() {
    return this.facilityTime;
  }

  setIndexLocation(index: number) {
    this.indexLocation = index;
  }

  getIndexLocation(): number {
    return this.indexLocation;
  }

}
