import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormControl, Validators } from '@angular/forms';
import 'moment-range';
import 'moment/locale/fr';
import 'moment/locale/es';
import 'moment/locale/de';
import 'moment/locale/en-gb';
import 'moment/locale/ar';
import 'moment/locale/hi';

@Component({
  selector: 'app-facilityTime.dialog',
  templateUrl: '../../dialogs/facilityTime/facilityTime.dialog.html',
  styleUrls: ['../../dialogs/facilityTime/facilityTime.dialog.css']
})
export class FacilityTimeDialogComponent implements OnInit {

  facilityTimeOb = [
    {
      checked: false,
      day: 'Sun',
      from: '',
      to: ''
    },
    {
      checked: false,
      day: 'Mon',
      from: '',
      to: ''
    },
    {
      checked: false,
      day: 'Tue',
      from: '',
      to: ''
    },
    {
      checked: false,
      day: 'Wed',
      from: '',
      to: ''
    },
    {
      checked: false,
      day: 'Thr',
      from: '',
      to: ''
    },
    {
      checked: false,
      day: 'Fri',
      from: '',
      to: ''
    }, {
      checked: false,
      day: 'Sat',
      from: '',
      to: ''
    }
  ];

  constructor(public dialogRef: MatDialogRef<FacilityTimeDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any
    , public dataService: DataService) {
  }
  ngOnInit(): void {
    if (this.data.facilityTime !== '') {
      this.facilityTimeOb = this.data.facilityTime;
    }
  }

  formControl = new FormControl('', [Validators.required]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
  }

  checkedAll(event) {
    this.facilityTimeOb.forEach((item, index) => {
      this.facilityTimeOb[index].checked = event.checked;
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  ApplyToAllChecked(i, facilityTimeOb): void {
    console.log(facilityTimeOb);
    let ob = this.facilityTimeOb[i];
    this.facilityTimeOb.forEach((item, index) => {
      if (item.checked) {
        this.facilityTimeOb[index] = ob;
      }
    });
  }

  dataChanged(newObj, prop) {
    let time = newObj[prop];
    var regex = new RegExp("^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$");

    if (regex.test(time)) {
      let hour = (time.split(':'))[0];
      let min = (time.split(':'))[1];
      min = (min + '').length == 1 ? `0${min}` : min;
      hour = hour > 12 ? hour - 12 : hour;
      hour = (hour + '').length == 1 ? `0${hour}` : hour;
      newObj[prop] = `${hour}:${min}`;
    }
  }

  public confirmAdd(): void {
    this.dataService.addFacilityTime(this.facilityTimeOb);
  }
}
