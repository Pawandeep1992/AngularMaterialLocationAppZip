import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material/dialog';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormControl, Validators } from '@angular/forms';
import { Location } from '../../models/location';
import * as moment from 'moment-timezone';

import 'moment-range';
import 'moment/locale/fr';
import 'moment/locale/es';
import 'moment/locale/de';
import 'moment/locale/en-gb';
import 'moment/locale/ar';
import 'moment/locale/hi';
import { FacilityTimeDialogComponent } from '../facilityTime/facilityTime.dialog.component';
import { fromEvent } from 'rxjs';
import { COMMA } from '@angular/cdk/keycodes';
import { MatAutocomplete } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';

@Component({
  selector: 'app-add.dialog',
  templateUrl: './add.dialog.html',
  styleUrls: ['./add.dialog.css']
})
export class AddDialogComponent implements OnInit {
  selectedValue: string;
  states = ["Delhi", "Punjab", "Maharashtra"];
  public tzNames: string[];
  visible = true;
  removable = true;
  addOnBlur = true;
  separatorKeysCodes: number[] = [COMMA];
  appointmentPool: string[] = [];
  @ViewChild('auto', { static: false }) matAutocomplete: MatAutocomplete;
  formControl = new FormControl('', [Validators.required]);
  dialogNameType: any;

  constructor(public dialogRef: MatDialogRef<AddDialogComponent>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dataService: DataService) {
    this.tzNames = moment.tz.names();
  }

  ngOnInit(): void {
    this.dialogNameType = this.data.type;
    if (this.data.appointmentPool && (this.data.appointmentPool != '')) {
      this.appointmentPool = this.data.appointmentPool.split(",");
    }
    const debounceTimeEvent = fromEvent(document.getElementById('clickEventFT'), 'click');
    debounceTimeEvent.subscribe(() => {
      this.addFacilityTime();
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.data.appointmentPool = this.appointmentPool.join(',');
    if (this.data.type === 'Add') {
      delete this.data.type;
      this.dataService.addLocation(this.data, this.dialogRef);
    } else {
      delete this.data.type;
      this.dataService.updateLocation(this.data, this.dialogRef);
    }
  }

  addFacilityTime() {
    let facilityTime = (this.data.facilityTime && this.data.facilityTime !== "") ?
      JSON.parse(this.data.facilityTime) : ''
    const dialogRef = this.dialog.open(FacilityTimeDialogComponent, {
      data: { facilityTime: facilityTime }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.data.facilityTime = JSON.stringify(this.dataService.getFacilityTime());
      }
    });
  }

  addAppointment(event: MatChipInputEvent): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      if ((value || '').trim()) {
        this.appointmentPool.push(value.trim());
      }
      if (input) {
        input.value = '';
      }
    }
  }

  removeAppointment(appointmentPool: string): void {
    const index = this.appointmentPool.indexOf(appointmentPool);
    if (index >= 0) {
      this.appointmentPool.splice(index, 1);
    }
  }
}
