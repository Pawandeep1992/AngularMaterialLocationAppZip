import { Component, ElementRef, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { DataService } from '../services/data.service';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Location } from '../models/location';
import { DataSource } from '@angular/cdk/collections';
import { AddDialogComponent } from '../dialogs/add/add.dialog.component';
import { DeleteDialogComponent } from '../dialogs/delete/delete.dialog.component';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public httpClient: HttpClient,
    public dialog: MatDialog,
    public dataService: DataService) { }

  @Output() outside = new EventEmitter();

  ngOnInit() {
  }

  addNew() {
    const dialogRef = this.dialog.open(AddDialogComponent, {
      data: { location: Location, type: 'Add' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        setTimeout(()=> {
          this.outside.emit('NewLocationAdded');
        },1000);
      }
    });
  }

}
