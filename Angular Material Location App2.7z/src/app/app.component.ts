import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { Location } from './models/location';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

  isAnyLocationAvailable = false;

  constructor(public httpClient: HttpClient,
    public dialog: MatDialog,
    public dataService: DataService) { }

  ngOnInit() {
    this.httpClient.get<Location[]>(this.dataService.API_URL).subscribe((data) => {
      if (data.length > 0) {
        this.isAnyLocationAvailable = true;
      }
    });
  }

  firstLocationAdded(event) {
    this.isAnyLocationAvailable = true;
  }

}
