export class Location {
  locationName: string;
  city: string;
  state: string;
  zipCode: string;
  phoneNumber: number;
  timeZone : string;
  facilityTime : string;
  appointmentPool: string;
  id: number;
}
