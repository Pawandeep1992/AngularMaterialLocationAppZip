import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {Location} from '../models/location';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';

@Injectable()
export class DataService {
  private readonly API_URL = 'http://localhost:3000/posts/';

  dataChange: BehaviorSubject<Location[]> = new BehaviorSubject<Location[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  facilityTime: any;

  constructor (private httpClient: HttpClient) {}

  get data(): Location[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  /** CRUD METHODS */
  getAllLocations(): void {

    this.httpClient.get<Location[]>(this.API_URL).subscribe(data => {
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
      console.log (error.name + ' ' + error.message);
      });
  }

  // DEMO ONLY, you can find working methods below
  addLocation (location: Location): void {
    this.dialogData = location;
  }

  updateLocation (location: Location): void {
    this.dialogData = location;
  }

  deleteLocation (locationName: string): void {
    console.log(locationName);
  }

  addFacilityTime(data) {
    this.facilityTime = data;
  }

  getFacilityTime() {
    return this.facilityTime;
  }

}
