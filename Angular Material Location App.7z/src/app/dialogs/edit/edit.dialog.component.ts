import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material/dialog';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormControl, Validators } from '@angular/forms';
import { fromEvent } from 'rxjs';
import { COMMA } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { FacilityTimeDialogComponent } from '../facilityTime/facilityTime.dialog.component';

@Component({
  selector: 'app-baza.dialog',
  templateUrl: '../../dialogs/edit/edit.dialog.html',
  styleUrls: ['../../dialogs/edit/edit.dialog.css']
})
export class EditDialogComponent implements OnInit {

  formControl = new FormControl('', [Validators.required]);
  visible = true;
  removable = true;
  addOnBlur = true;
  separatorKeysCodes: number[] = [COMMA];
  appointmentPool: string[] = [];
  @ViewChild('auto', { static: false }) matAutocomplete: MatAutocomplete;

  constructor(public dialogRef: MatDialogRef<EditDialogComponent>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any, public dataService: DataService) {
  }

  ngOnInit(): void {
    if (this.data.appointmentPool && (this.data.appointmentPool != '')) {
      this.appointmentPool = this.data.appointmentPool.split(",");
    }
    const debounceTimeEvent = fromEvent(document.getElementById('clickEventFT'), 'click');
    debounceTimeEvent.subscribe(() => {
      this.addFacilityTime();
    });
  }

  addFacilityTime() {
    const dialogRef = this.dialog.open(FacilityTimeDialogComponent, {
      data: { facilityTime: this.data.facilityTime === '' ? this.data.facilityTime : JSON.parse(this.data.facilityTime) }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.data.facilityTime = JSON.stringify(this.dataService.getFacilityTime());
    });
  }

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  stopEdit(): void {
    this.data.appointmentPool = this.appointmentPool.join(',');
    this.dataService.updateLocation(this.data);
  }

  add(event: MatChipInputEvent): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      if ((value || '').trim()) {
        this.appointmentPool.push(value.trim());
      }
      if (input) {
        input.value = '';
      }
    }
  }

  remove(appointmentPool: string): void {
    const index = this.appointmentPool.indexOf(appointmentPool);

    if (index >= 0) {
      this.appointmentPool.splice(index, 1);
    }
  }

}
