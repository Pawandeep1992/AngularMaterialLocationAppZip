import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material/dialog';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../services/data.service';
import { FormControl, Validators } from '@angular/forms';
import { Location } from '../../models/location';
import { TimeZoneService } from '../../time-zone.service';
import * as moment from 'moment-timezone';
import { Moment } from 'moment';

import 'moment-range';
import 'moment/locale/fr';
import 'moment/locale/es';
import 'moment/locale/de';
import 'moment/locale/en-gb';
import 'moment/locale/ar';
import 'moment/locale/hi';
import { FacilityTimeDialogComponent } from '../facilityTime/facilityTime.dialog.component';
import { fromEvent } from 'rxjs';
import {COMMA} from '@angular/cdk/keycodes';
import {MatAutocompleteSelectedEvent, MatAutocomplete} from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';

@Component({
  selector: 'app-add.dialog',
  templateUrl: '../../dialogs/add/add.dialog.html',
  styleUrls: ['../../dialogs/add/add.dialog.css']
})
export class AddDialogComponent implements OnInit {
  selectedValue: string;
  states = ["Delhi", "Punjab", "Maharashtra"];
  public tzNames: string[];
  visible = true;
  removable = true;
  addOnBlur = true;
  separatorKeysCodes: number[] = [COMMA];
  appointmentPool: string[] = [];
  @ViewChild('auto', {static: false}) matAutocomplete: MatAutocomplete;
  formControl = new FormControl('', [Validators.required]);

  constructor(public dialogRef: MatDialogRef<AddDialogComponent>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: Location,
    public dataService: DataService) {
    this.tzNames = moment.tz.names();
  }

  ngOnInit(): void {
    const debounceTimeEvent = fromEvent(document.getElementById('clickEventFT'), 'click');
    debounceTimeEvent.subscribe(() => {
      this.addFacilityTime();
    });
  }
  
  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.data.appointmentPool = this.appointmentPool.join(',');
    this.dataService.addLocation(this.data);
  }

  addFacilityTime() {
    const dialogRef = this.dialog.open(FacilityTimeDialogComponent, {
      data: { facilityTime : "" }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.data.facilityTime = JSON.stringify(this.dataService.getFacilityTime());
    });
  }

  add(event: MatChipInputEvent): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      if ((value || '').trim()) {
        this.appointmentPool.push(value.trim());
      }
      if (input) {
        input.value = '';
      }
    }
  }

  remove(appointmentPool: string): void {
    const index = this.appointmentPool.indexOf(appointmentPool);

    if (index >= 0) {
      this.appointmentPool.splice(index, 1);
    }
  }
}
